package com.example.infotabs

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentContainer

class Tab1Frag:Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater,container: ViewGroup?,
        savedInstanceState: Bundle?):
            View? {
                val view=inflater.inflate(R.layout.fragment_tab1,container,false)
                val textView=view.findViewById<TextView>(R.id.text1)
                textView.text="Tab1 content"
                return view
            }
}