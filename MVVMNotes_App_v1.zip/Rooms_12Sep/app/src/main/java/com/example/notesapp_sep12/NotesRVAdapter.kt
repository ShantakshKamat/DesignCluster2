package com.example.notesapp_sep12

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.AppCompatImageView
import androidx.recyclerview.widget.RecyclerView

class NotesRVAdapter(private val context: Context, private val listener: INotesRvAdapter):RecyclerView.Adapter<NotesRVAdapter.NoteViewHolder>() {

    val allnotes=ArrayList<Note>()

    inner class NoteViewHolder(itemView: View) :RecyclerView.ViewHolder(itemView){
        val textview=itemView.findViewById<TextView>(R.id.text)
        val deletebtn=itemView.findViewById<ImageView>(R.id.delete_btn)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val viewHolder=NoteViewHolder(LayoutInflater.from(context).inflate(R.layout.item,parent,false))
        viewHolder.deletebtn.setOnClickListener{
            listener.onItemClicked(allnotes[viewHolder.adapterPosition])
        }
        return viewHolder
    }

    override fun getItemCount(): Int {
        return allnotes.size
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        val currentNote=allnotes[position]
        holder.textview.text=currentNote.text
    }


    fun updateList(newList:List<Note>){
        allnotes.clear()
        allnotes.addAll(newList)
        notifyDataSetChanged()
    }
}

interface INotesRvAdapter {
    fun onItemClicked(note: Note)
}