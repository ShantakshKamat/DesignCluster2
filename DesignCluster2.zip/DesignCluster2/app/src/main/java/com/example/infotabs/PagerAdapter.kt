package com.example.infotabs

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter

class PagerAdapter(f:FragmentManager):FragmentPagerAdapter(f) {
    override fun getCount(): Int=2

    override fun getItem(position: Int): Fragment {
        return when(position){
            0->Tab1Frag()
            1->Tab2Frag()
            2->Tab3Frag()
            3->Tab1Frag()
            4->Tab2Frag()
            5->Tab3Frag()
            6->Tab1Frag()
            7->Tab2Frag()
            8->Tab3Frag()
            9->Tab1Frag()
            10->Tab2Frag()
            11->Tab3Frag()
            else->Tab1Frag()
        }
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return when(position){
            0->"Tab1"
            1->"Tab2"
            2->"Tab3"
            3->"Tab4"
            4->"Tab5"
            5->"Tab6"
            6->"Tab7"
            7->"Tab8"
            8->"Tab9"
            9->"Tab10"
            10->"Tab11"
            11->"Tab12"
            else->" "
        }
    }
}