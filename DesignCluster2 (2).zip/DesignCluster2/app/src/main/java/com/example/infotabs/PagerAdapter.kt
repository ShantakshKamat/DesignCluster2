package com.example.infotabs

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter

class PagerAdapter(f:FragmentManager):FragmentPagerAdapter(f) {
    override fun getCount(): Int=5

    override fun getItem(position: Int): Fragment {
        return when(position){
            0->HomeFragment()
            1->Tab2Frag()
            2->Tab3Frag()
            3->Tab1Frag()
            4->Tab2Frag()
            5->Tab3Frag()
            else->Tab1Frag()
        }
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return when(position){
            0->"Trending News"
            1->"About"
            2->"CarZone"
            3->"Settings"
            4->"Info"
            5->"Tab6"
            else->" "
        }
    }
}