package com.example.infotabs

data class News(var titleImage:Int,var heading:String)
